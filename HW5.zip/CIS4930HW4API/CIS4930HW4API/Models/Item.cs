﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CIS4930HW4API.Models
{
    [JsonConverter(typeof(ProductJsonConverter))]
    public class Item
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Priority { get; set; }
        public string PriorityDisplay
        {
            get
            {
                if (Priority == 0) //priority default is 0
                    return "low";
                else if (Priority == 1)
                    return "medium";
                else if (Priority == 2)
                    return "high";
                else
                    return "";
            }
        }
        public int Id { get; set; }

    }
}
