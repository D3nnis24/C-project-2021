﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace CIS4930HW4API.Models
{
    [JsonConverter(typeof(ProductJsonConverter))]
    public class Appointment : Item
    {
        public Appointment() : base()
        {

        }
        public DateTime Start { get; set; }
        public DateTime Stop { get; set; }
        public List<string> Attendees { get; set; }


        public override string ToString()
        {
            return $"(Appointment)\n Name: {Name}\n Description: {Description}\n Start: {Start}\n Stop: {Stop}\n Attendees: {(Attendees?.Count == 0 ? "No Attendees" : string.Join(",", Attendees))}\n Priority: {PriorityDisplay}";
        }
    }
}
