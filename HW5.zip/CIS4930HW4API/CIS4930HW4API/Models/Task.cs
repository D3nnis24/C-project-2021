﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace CIS4930HW4API.Models
{
    [JsonConverter(typeof(ProductJsonConverter))]
    public class Task : Item
    {
        public Task() : base()
        {

        }
        public DateTime Deadline { get; set; }
        public bool IsCompleted { get; set; }

        public override string ToString()
        {
            return $"(Task)\n Name: {Name}\n Description: {Description}\n Deadline: {Deadline}\n Is Completed: {(IsCompleted ? "yes" : "no")}\n Priority {PriorityDisplay}";
        }
    }
}
