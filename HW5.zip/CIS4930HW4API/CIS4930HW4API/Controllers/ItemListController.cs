﻿using CIS4930HW4API.Models;
using CIS4930HW4API.Services;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CIS4930HW4API.Controllers
{
    [ApiController]
    [Route("ItemList")]
    public class ItemListController : ControllerBase
    {
        [HttpGet("Test")]
        public string Test()
        {
            return "{\"testing\"}"; 
        }

        [HttpGet("GetAll")]
        public ActionResult<List<Item>> Get()
        {
            var i = new ItemListService();
            return Ok(i.GetAll());
        }

        [HttpGet("GetCompletedTasks")]
        public ActionResult<List<Item>> GetCompleteTasks()
        {
            var i = new ItemListService();
            return Ok(i.GetCompletedTasks());
        }

        [HttpGet("GetOutstandingTasks")]
        public ActionResult<List<Item>> GetOutStandingTasks()
        {
            var i = new ItemListService();
            return Ok(i.GetOutstandingTasks());
        }

        [HttpGet("GetAllTasks")]
        public ActionResult<List<Item>> GetAllTasks()
        {
            var i = new ItemListService();
            return Ok(i.GetAllTasks());
        }

        [HttpGet("GetAllAppointments")]
        public ActionResult<List<Item>> GetAllAppointments()
        {
            var i = new ItemListService();
            return Ok(i.GetAllAppointments());
        }

        [HttpPost("AddOrUpdate")]
        public ActionResult<Item> AddOrUpdate([FromBody] Item item)
        {
            if (item == null) //item passed in is invalid
            {
                return BadRequest();
            }

            var i = new ItemListService();
            if (item?.Id == null) //adding a new item
            {
                return Ok(i.Add(item));          
            }
            else //updating an item
            {
                return Ok(i.Update(item));
            }
        }

        
        [HttpPost("Delete")]
        public ActionResult<Item> Delete([FromBody] Item item)
        {
            var i = new ItemListService();
            return Ok(i.Delete(item));
        }
        
        [HttpPost("Search")]
        public ActionResult<List<Item>> Search([FromBody]string searchString)
        {
            var i = new ItemListService();
            return Ok(i.Search(searchString));
        }
        
    }
}
