﻿using CIS4930HW4API.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace CIS4930HW4API.Services
{
    public class ItemListService
    {
        private string connectionString;
        public ItemListService()
        {
            connectionString = "Server=.;Database=Items;Trusted_Connection=True;";
        }
        private List<Item> ExtractTasks(SqlDataReader reader)
        {
            var returnList = new List<Item>();
            while (reader.Read())
            {
                var returnTask = new Models.Task();
                returnTask.Id = (int)reader["Id"];
                returnTask.Name = (string)reader["Name"];
                returnTask.Description = (string)reader["Description"];
                returnTask.Priority = (int)reader["Priority"];
                returnTask.Deadline = (DateTime)reader["Deadline"];
                returnTask.IsCompleted = !Convert.ToBoolean(reader["IsCompleted"]);

                returnList.Add(returnTask);
            }
            return returnList;
        }
        private List<Item> ExtractAppointment(SqlDataReader reader)
        {
            var returnList = new List<Item>();
            while (reader.Read())
            {
                var returnAppt = new Appointment();
                returnAppt.Id = (int)reader["Id"];
                returnAppt.Name = (string)reader["Name"];
                returnAppt.Description = (string)reader["Description"];
                returnAppt.Priority = (int)reader["Priority"];
                returnAppt.Start = (DateTime)reader["Start"];
                returnAppt.Stop = (DateTime)reader["Stop"];
                
                string AttendeesString = (string)reader["Attendees"];
                List<string> Attds = AttendeesString.Split(',').ToList();
                returnAppt.Attendees = Attds;

                returnList.Add(returnAppt);
            }
            return returnList;
        }
        private List<Item> RenderView(string sql, string table, string param = null)
        {
            List<Item> returnList;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                var cmd = new SqlCommand(sql, connection);
                connection.Open();
                if(param != null)
                    cmd.Parameters.Add(new SqlParameter("@1", param));
                
                var reader = cmd.ExecuteReader();
                //check whether we are extracting from task or appointment table
                if (table == "a")
                    returnList = ExtractAppointment(reader);
                else 
                    returnList = ExtractTasks(reader);
                
                connection.Close();
            }
            return returnList;
        }
        
        //Functions that use Queries
        public List<Item> GetAll()
        {
            return GetAllAppointments().Concat(GetAllTasks()).ToList();
        }
        public List<Item> GetAllTasks()
        {
            var sql = "select * from GetAllTasks";
            return RenderView(sql, "t");
        }
        public List<Item> GetAllAppointments()
        {
            var sql = "select * from GetAllAppointments";
            return RenderView(sql, "a");
        }
        public List<Item> GetCompletedTasks()
        {
            var sql = "select * from GetCompletedTasks";
            return RenderView(sql, "t");
        }
        public List<Item> GetOutstandingTasks()
        {
            var sql = "select * from GetOutstandingTasks";
            return RenderView(sql, "t");
        }


        //Functions that update the database
        public Item Add(Item i)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                //check if Item is a Task or Appointment
                if(i is Models.Task)
                {
                    Models.Task t = (Models.Task)i;
                    var sql = $"Insert Into Tasks (Name, Description, Priority, Deadline, IsCompleted) " +
                          $"Values(@1,@2,@3,@4,@5)";
                    var cmd = new SqlCommand(sql, connection);
                    cmd.Parameters.Add(new SqlParameter("@1", t.Name));
                    cmd.Parameters.Add(new SqlParameter("@2", t.Description));
                    cmd.Parameters.Add(new SqlParameter("@3", t.Priority));
                    cmd.Parameters.Add(new SqlParameter("@4", t.Deadline));
                    cmd.Parameters.Add(new SqlParameter("@5", t.IsCompleted == true ? 0 : 1 ));

                    connection.Open();
                    var reader = cmd.ExecuteNonQuery();
                    connection.Close();
                }
                else if(i is Appointment)
                {
                    Appointment t = (Appointment)i;
                    var sql = $"Insert Into Appointments (Name, Description, Priority, Start, Stop, Attendees) " +
                          $"Values(@1,@2,@3,@4,@5,@6)";
                    var cmd = new SqlCommand(sql, connection);
                    cmd.Parameters.Add(new SqlParameter("@1", t.Name));
                    cmd.Parameters.Add(new SqlParameter("@2", t.Description));
                    cmd.Parameters.Add(new SqlParameter("@3", t.Priority));
                    cmd.Parameters.Add(new SqlParameter("@4", t.Start));
                    cmd.Parameters.Add(new SqlParameter("@5", t.Start));
                    cmd.Parameters.Add(new SqlParameter("@6", string.Join(",", t.Attendees)));

                    connection.Open();
                    var reader = cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return i;
        }

        public Item Delete(Item i)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                //check if Item is a Task or Appointment
                if (i is Models.Task)
                {
                    Models.Task t = (Models.Task)i;
                    var sql = $"Delete From Tasks Where Id = @1";
                    var cmd = new SqlCommand(sql, connection);
                    cmd.Parameters.Add(new SqlParameter("@1", t.Id));

                    connection.Open();
                    var reader = cmd.ExecuteNonQuery();
                    connection.Close();
                }
                else if (i is Appointment)
                {
                    Appointment t = (Appointment)i;
                    var sql = $"Delete From Appointments Where Id = @1";
                    var cmd = new SqlCommand(sql, connection);
                    cmd.Parameters.Add(new SqlParameter("@1", t.Id));

                    connection.Open();
                    var reader = cmd.ExecuteNonQuery();
                    connection.Close();
                }
            }
            return i;
        }
        public Item Update(Item i)
        {
            Delete(i);
            Add(i);
            return i;
        }
        
        public List<Item> Search(string searchString)
        {

            var sql1 = $"Select * From Tasks Where Name like '%' + @1 + '%' OR Description like '%' + @1 + '%'";
            var sql2 = $"Select * From Appointments Where Name like '%' + @1 + '%' OR Description like '%' + @1 + '%' OR Attendees like '%' + @1 + '%'";
            
            var List1 = RenderView(sql1, "t", searchString);
            var List2 = RenderView(sql2, "a", searchString);
            
            return List1.Concat(List2).ToList();
        }
    }
}
