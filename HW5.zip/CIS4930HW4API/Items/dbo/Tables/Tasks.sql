﻿CREATE TABLE [dbo].[Tasks](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](max) NULL,
	[Description] [nvarchar](max) NULL,
	[Priority] [int] NULL,
	[Deadline] [datetime] NULL,
	[IsCompleted] [bit] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]