﻿CREATE TABLE [dbo].[Appointments](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Name] [varchar](max) NULL,
	[Description] [varchar](max) NULL,
	[Priority] [int] NULL,
	[Start] [datetime] NULL,
	[Stop] [datetime] NULL,
	[Attendees] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]