﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using HW3.Dialogs;
using HW3.Models;
using HW3.ViewModels;
using Newtonsoft.Json;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace HW3
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
            DataContext = new ItemManager();
        }
        /* The following invoke dialogs */
        private async void AddTask(object sender, RoutedEventArgs e)
        {
            var diag = new TaskDialog((DataContext as ItemManager).ItemList);
            await diag.ShowAsync();
            (DataContext as ItemManager).AddOrUpdate();
        }

        private async void AddAppointment(object sender, RoutedEventArgs e)
        {
            var diag = new AppointmentDialog((DataContext as ItemManager).ItemList);
            await diag.ShowAsync();
            (DataContext as ItemManager).AddOrUpdate();

        }
        private async void Edit(object sender, RoutedEventArgs e)
        {
            //check if an item is selected
            var obj = (DataContext as ItemManager)?.SelectedItem;
            if (obj != null)
            {
                if(obj is Task)
                {
                    var diag = new TaskDialog((Task)(DataContext as ItemManager).SelectedItem, (DataContext as ItemManager).ItemList);
                    await diag.ShowAsync();
                }
                else if(obj is Appointment)
                {
                    var diag = new AppointmentDialog((Appointment)((DataContext as ItemManager).SelectedItem), (DataContext as ItemManager).ItemList);
                    await diag.ShowAsync();
                }
                (DataContext as ItemManager).AddOrUpdate();

            }
        }
        private async void Save(object sender, RoutedEventArgs e)
        {
            var diag = new LoadSaveDialog((DataContext as ItemManager), 0);
            await diag.ShowAsync();
        }
        private async void Load(object sender, RoutedEventArgs e)
        {
            var diag = new LoadSaveDialog((DataContext as ItemManager), 1);
            await diag.ShowAsync();
        }
        /*The following dont invoke Dialogs */
        private void Delete(object sender, RoutedEventArgs e)
        {
            (DataContext as ItemManager).Delete();
        }

        private void SortByPriority(object sender, RoutedEventArgs e)
        {
            (DataContext as ItemManager).SortByPriority();
        }
        private void CompletedTasks(object sender, RoutedEventArgs e)
        {
            (DataContext as ItemManager).GetCompletedTasks();
        }
        private void OutstandingTasks(object sender, RoutedEventArgs e)
        {
            (DataContext as ItemManager).GetOutstandingTasks();
        }
        private void AllTasks(object sender, RoutedEventArgs e)
        {
            (DataContext as ItemManager).GetAllTasks();
        }
        private void AllAppointments(object sender, RoutedEventArgs e)
        {
            (DataContext as ItemManager).GetAllAppointments();
        }
        private void TasksAndAppointments(object sender, RoutedEventArgs e)
        {
            (DataContext as ItemManager).GetAll();
        }
        private void Search(object sender, RoutedEventArgs e)
        {
            if(keyword.Text != null)
                (DataContext as ItemManager).SearchKeyword(keyword.Text);
        }
    }
}
