﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using HW3.Models;
using HW3.ViewModels;
using Newtonsoft.Json;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Content Dialog item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace HW3.Dialogs
{
    public sealed partial class AppointmentDialog : ContentDialog
    {
        private IList<Item> items;
        public Appointment appt { get; set; }


        /*Use to Bind to list of Attendees */
        private string stringOfAttendees;
        public string StringOfAttendees 
        {
            get //returning a comma seperated string from string list
            {
                //check if Attendees is empty
                if (appt.Attendees == null)
                    stringOfAttendees = "";
                else
                    stringOfAttendees = string.Join(",", appt.Attendees);
                return stringOfAttendees;
            }
            set //we are passing in a comma seperated string
            {
                if (stringOfAttendees != value)
                {
                    stringOfAttendees = value;
                    appt.Attendees = value?.Split(new char[] { ',' })?.ToList() ?? new List<string>();
                    appt.Attendees = appt.Attendees.Where(t => !string.IsNullOrEmpty(t)).ToList();
                }
            }
        }

        /*Used to Bind to Start DateTime*/
        private DateTimeOffset boundDate1;
        public DateTimeOffset BoundDate1
        {
            get
            {
                return boundDate1;
            }
            set
            {
                boundDate1 = value;
                appt.Start = boundDate1.Date;
            }
        }

        /*Used to Bind to Stop DateTime*/
        private DateTimeOffset boundDate2;
        public DateTimeOffset BoundDate2
        {
            get
            {
                return boundDate2;
            }
            set
            {
                boundDate2 = value;
                appt.Stop = boundDate2.Date;
            }
        }

        public AppointmentDialog(IList<Item> items) //Adding new Appointment
        {
            this.InitializeComponent();
            this.items = items;
            this.appt = new Appointment();
            this.appt.Attendees = new List<string>();
            BoundDate1 = DateTime.Now;
            BoundDate2 = DateTime.Now;
            DataContext = this;
        }

        public AppointmentDialog(Appointment selectedItem, IList<Item> items) //Editing Appointment
        {
            this.InitializeComponent();
            this.items = items;
            this.appt = selectedItem;
            BoundDate1 = appt.Start;
            BoundDate2 = appt.Stop;
            DataContext = this;
        }

        private async void ContentDialog_PrimaryButtonClick(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
            var thisItem = appt as Item;
            thisItem = JsonConvert.DeserializeObject<Item>(await new WebRequestHandler().Post("http://localhost/CIS4930HW4API/ItemList/AddOrUpdate", thisItem));

            var index = items.IndexOf(items.FirstOrDefault(t => t.Id.Equals(thisItem.Id)));
            if (index < 0) //adding an appointment 
            {
                items.Add(thisItem);
            }
            else //editting an appointment
            {
                items.RemoveAt(index);
                items.Insert(index, thisItem);
            }
        }

        private void ContentDialog_SecondaryButtonClick(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
        }
    }
}
