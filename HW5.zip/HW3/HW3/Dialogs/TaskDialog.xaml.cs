﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using HW3.Models;
using HW3.ViewModels;
using Newtonsoft.Json;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Content Dialog item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace HW3.Dialogs
{
    public sealed partial class TaskDialog : ContentDialog
    {
        private IList<Item> items;
        public Task t { get; set; }

        /*Used to Bind to Deadline DateTime*/
        private DateTimeOffset boundDate1;
        public DateTimeOffset BoundDate1
        {
            get
            {
                return boundDate1;
            }
            set
            {
                boundDate1 = value;
                t.Deadline = boundDate1.Date;
            }
        }
        public TaskDialog(IList<Item> items)
        {
            this.InitializeComponent();
            t = new Task();
            BoundDate1 = DateTime.Now;
            this.items = items;
            DataContext = this;
        }
        public TaskDialog(Task selectedItem, IList<Item> items)
        {
            this.InitializeComponent();
            t = selectedItem;
            BoundDate1 = t.Deadline;
            this.items = items;
            DataContext = this;
        }
        private async void ContentDialog_PrimaryButtonClick(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
            var thisItem = t as Item;
            thisItem = JsonConvert.DeserializeObject<Item>(await new WebRequestHandler().Post("http://localhost/CIS4930HW4API/ItemList/AddOrUpdate", thisItem));

            var index = items.IndexOf(items.FirstOrDefault(t => t.Id.Equals(thisItem.Id)));
            if (index < 0) //adding an task 
            {
                items.Add(thisItem);
            }
            else //editting an task
            {
                items.RemoveAt(index);
                items.Insert(index, thisItem);
            }
        }
        private void ContentDialog_SecondaryButtonClick(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
        }
    }
}
