﻿using HW3.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Content Dialog item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace HW3.Dialogs
{
    public sealed partial class ListOfAttendees : ContentDialog, INotifyPropertyChanged
    {
        private Appointment item;

        private string attendeeString;
        public string AttendeesString
        {
            get
            {
                return attendeeString;
            }
            set
            {
                attendeeString = value;
                NotifyPropertyChanged("Attendees");
            }
        }

        private ObservableCollection<string> attendees;
        public ObservableCollection<string> Attendees
        {
            get
            {
                attendees = new ObservableCollection<string>();
                var list = AttendeesString?.Split(new char[] { ',' })?.ToList() ?? new List<string>();
                list.Where(t => !string.IsNullOrEmpty(t)).ToList().ForEach(attendees.Add);
                return attendees;
            }
        }

        public ListOfAttendees(Appointment app)
        {
            this.InitializeComponent();
            if (app.Attendees == null) //Making a new Attendees List
                attendees = new ObservableCollection<string>();
            else //Editing an existing List
                attendees = new ObservableCollection<string>(app.Attendees);
            item = app;
            DataContext = this;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private void ContentDialog_PrimaryButtonClick(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
            item.Attendees = attendees.ToList<string>();
        }

        private void ContentDialog_SecondaryButtonClick(ContentDialog sender, ContentDialogButtonClickEventArgs args)
        {
        }
    }
}
