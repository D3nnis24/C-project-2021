﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using HW3.Models;
using Newtonsoft.Json;

namespace HW3.ViewModels
{
    //this class will handle all communication with the API
    public class ItemManager : INotifyPropertyChanged
    {
        /*properties*/
        public event PropertyChangedEventHandler PropertyChanged;
        public Item SelectedItem { get; set; }
        public ObservableCollection<Item> ItemList { get; set; }
        
        /*constructor*/
        public ItemManager()
        {
            ItemList = new ObservableCollection<Item>();
            GetAll();
        }

        /* private functions*/
        private void NotifyPropertyChanged([CallerMemberName] string propertyName = "")
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        /* public functions involving GET communication with API */
        public void GetAll()
        {
            var handler = new WebRequestHandler();
            var sample = JsonConvert.DeserializeObject<List<Item>>(handler.Get("http://localhost/CIS4930HW4API/ItemList/GetAll").Result);
            ItemList = new ObservableCollection<Item>(sample);
            NotifyPropertyChanged("ItemList");
        }
        public void GetCompletedTasks()
        {
            var handler = new WebRequestHandler();
            var sample =  JsonConvert.DeserializeObject<List<Item>>(handler.Get("http://localhost/CIS4930HW4API/ItemList/GetCompletedTasks").Result);
            ItemList = new ObservableCollection<Item>(sample);
            NotifyPropertyChanged("ItemList");
        }
        public void GetOutstandingTasks()
        {
            var handler = new WebRequestHandler();
            var sample = JsonConvert.DeserializeObject<List<Item>>(handler.Get("http://localhost/CIS4930HW4API/ItemList/GetOutstandingTasks").Result);
            ItemList = new ObservableCollection<Item>(sample);
            NotifyPropertyChanged("ItemList");
        }
        public void GetAllTasks()
        {
            var handler = new WebRequestHandler();
            var sample = JsonConvert.DeserializeObject<List<Item>>(handler.Get("http://localhost/CIS4930HW4API/ItemList/GetAllTasks").Result);
            ItemList = new ObservableCollection<Item>(sample);
            NotifyPropertyChanged("ItemList");
        }
        public void GetAllAppointments()
        {
            var handler = new WebRequestHandler();
            var sample = JsonConvert.DeserializeObject<List<Item>>(handler.Get("http://localhost/CIS4930HW4API/ItemList/GetAllAppointments").Result);
            ItemList = new ObservableCollection<Item>(sample);
            NotifyPropertyChanged("ItemList");
        }
        //All the above have been tested
        /* public functions involving POST communication with API */
        public async void SearchKeyword(string match)
        {
            var handler = new WebRequestHandler();
            var sample = JsonConvert.DeserializeObject<List<Item>>(await handler.Post("http://localhost/CIS4930HW4API/ItemList/Search", match));
            ItemList = new ObservableCollection<Item>(sample);
            NotifyPropertyChanged("ItemList");
        }
        public async void Delete()
        {
            if (SelectedItem != null)
            {
                var handler = new WebRequestHandler();
                var itemToRemove = JsonConvert.DeserializeObject<Item>(await handler.Post("http://localhost/CIS4930HW4API/ItemList/Delete", SelectedItem));
                ItemList.Remove(ItemList.FirstOrDefault(t => t.Id.Equals(itemToRemove.Id)));
                NotifyPropertyChanged("ItemList");
            }
        }

        public void AddOrUpdate()
        {
            NotifyPropertyChanged("ItemList");
        }
        /* public functions that dont involve communication */
        public void Load(string filename)
        {
            var directory = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var path = Path.Combine(directory, filename + ".json");

            //check if filename exsists
            if (File.Exists(path))
            {
                ItemList = JsonConvert.DeserializeObject<ObservableCollection<Item>>(File.ReadAllText(path), new ProductJsonConverter());
                NotifyPropertyChanged("ItemList");
            }
        }
        public void Save(string filename)
        {
            var directory = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var path = Path.Combine(directory, filename + ".json");

            //check if itemList is empty and if filename already exsists
            if (ItemList.Count != 0 && !File.Exists(path))
            {
                var list2Save = JsonConvert.SerializeObject(ItemList, new ProductJsonConverter());
                File.WriteAllText(path, list2Save);
            }
        }
        public void SortByPriority()
        {
           var sort = ItemList.OrderByDescending(i => i.Priority);
           ItemList = new ObservableCollection<Item>(sort);
           NotifyPropertyChanged("ItemList");
        }

    }
}
